---
id: DR-012
title: Run-log reading toolkit — filter, summarize, diff
summary: RunLog grows the reading side — filter selects, summarize condenses to the per-task account and verdict, diff compares two runs semantically (identity-keyed, timing excluded); IMP-022 implemented
date: 2026-10-14
status: accepted
layers: [product, architecture, implementation, verification]
state: docs/breakdown/01-product/uc-25-verify-two-runs-executed-identically.md
artifacts:
  - src/sequence_extensions/flow/runlog.py
  - src/sequence_extensions/flow/__init__.py
  - tests/flow/test_runlog_tools.py
  - docs/API.md
  - README.md
  - CHANGELOG.md
supersedes: []
superseded_by: []
related: [DR-005, DR-006, DR-010, DR-011]
---

# DR-012: Run-log reading toolkit — filter, summarize, diff

## Context

- `IMP-022` (filed from the 2026-10-14 functionality evaluation): the log is the executed truth and `INFO-001` names it diffable — but `records` is a one-shot full parse, so determinism checks are hand-written ad-hoc scripts.
- `DR-010`: use cases are need statements; two needs drive this — the compact account and the identical-execution proof.

## Decision

- Implement `IMP-022` as static methods beside `RunLog.records` — `filter` (kind / task / status / attempt selection), `summarize` (per-task attempts, statuses, compute time; the verdict), `diff` (semantic two-run comparison); all three accept a log path or a record list; `records` and the writer unchanged; `SCHEMA_VERSION` stays 1.
- Diff policy, stated: task records identify by task, inputs, and attempt number (run records by kind) — never position; duplicate identities: last wins; `DIFF_EXCLUDE` (order, `run_id`, wall-clock, `worker`) drops before comparing; a future argument's `done` snapshot is ignored; the report is jsonable and stably ordered.
- Two new need leaves: `CP-024` (see what a run did), `CP-025` (verify two runs executed identically).
- Release 1.2.0.

## Rationale

- Keying by what ran — not by file position — makes completion-order races invisible while outcome differences stay visible: exactly the determinism claim.
- Identity includes the inputs, so a fan-out (many attempts of one task) compares case by case, and a changed outcome is pinpointed to task, inputs, attempt, and fields.
- Static methods beside `records` keep one public surface for the log; the toolkit adds no module users must import.

## Alternatives Considered

- A separate `runlog_tools` module: rejected — `records` already lives on `RunLog`; a second import surface for the same log.
- Multiset comparison of whole records: rejected — loses the per-record field pinpointing (`changed`) that names exactly what moved.
- Filtering timing fields out of the report after comparing: rejected — exclusion is comparison policy and belongs in the compare, stated once as `DIFF_EXCLUDE`.

## Consequences

- Positive: two runs of the same code and inputs verify equal with one call; interrupted runs diff against complete ones (the missing verdict is listed); the account of a run is one jsonable dict.
- Negative: records with identical task, inputs, and attempt number but different content collapse to the last — indistinguishable duplicate submissions compare as one.
- The reading side is now public surface: its output shape is a compatibility promise.

## Verification

- `tests/flow/test_runlog_tools.py`: selection by every field; per-task account including skips and interrupted runs; two real two-stage campaigns (fan-out, dependency edges, retries) diff equal; a flaky difference pinpointed; timing-only differences and future `done` snapshots ignored; duplicate identity last-wins; `exclude=` override; jsonable, stably ordered output.

## Review Trigger

- A schema change to the record kinds, or a need to compare runs across schema versions.
