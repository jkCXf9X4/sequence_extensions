---
id: DR-007
title: Substrate reopen — pool-scoped cancellation and a public bind
summary: GraphPool.__exit__ cancels only the pool's own nodes (the global _LIVE_NODES sweep is removed) and GraphPool.bind(gf) becomes the public bind-without-results; the flow layer drops its private _bind_graph call
date: 2026-10-14
status: accepted
layers: [architecture, implementation, verification]
state: docs/breakdown/02-architecture/flow-engine-decorators-over-the-graph-substrate.md
artifacts:
  - src/sequence_extensions/graph/graph_future.py
  - src/sequence_extensions/flow/task.py
  - tests/graph/test_graph_future.py
  - tests/flow/test_flow.py
supersedes: []
superseded_by: []
related: [DR-005, DR-006]
---

# DR-007: Substrate reopen — pool-scoped cancellation and a public bind

## Context

- `DR-005` kept `graph.graph_future` untouched and deferred two follow-ups: `IMP-019` (pool-scoped cancellation) and `IMP-021` (public bind).
- `GraphPool.__exit__` walks the module-wide `_LIVE_NODES` weakset, so any pool exit cancels every pending node in the process.
- `IMP-021`: the only public bind-without-wait is `result(gf, timeout=0)`, which raises the node's own exception when it settles first.

## Decision

- `GraphPool.__exit__` cancels only nodes bound to that pool (`self._nodes`); the `_LIVE_NODES` weakset and its sweep are removed.
- `GraphPool.bind(gf)` is public: submit every ready leaf, raise `ValueError` on a cycle, never touch a result.
- `task.submit()` calls `pool.bind(gf)`; the private `_bind_graph` call leaves the flow layer.
- A dispatch seam `GraphPool._submit_node(node)` replaces the inline executor submit inside `GraphFuture._submit`, so pool subclasses can redirect execution.

## Rationale

- Concurrent flows in one process become safe: each pool cancels only its own graph.
- A completed-IMP-era private API workaround disappears behind a correct public call.
- The unbound-node safety net cost every cross-pool cancel; unbound nodes are a caller error the docstring now states.

## Alternatives Considered

- Keep the global sweep for unbound nodes only: rejected — keeps a cross-flow race window that can mislabel a skipped record.
- Leave `IMP-019` deferred: rejected — the process pool (`DR-008`) needs per-pool isolation.

## Consequences

- Positive: concurrent flows per process; pure public bind; smaller substrate.
- Negative: a node never bound to any pool is no longer cancelled by an unrelated pool exit — waiting on it hangs (caller error, documented).

## Verification

- `tests/graph/test_graph_future.py`: bind idempotency, cycle raise, settled-node no-raise, exit cancels own pending nodes, unrelated pool's nodes survive.
- `tests/flow/test_flow.py`: two concurrent flows in one process both complete.

## Review Trigger

- A caller depends on the old cross-pool cancel to clean up unbound nodes.
