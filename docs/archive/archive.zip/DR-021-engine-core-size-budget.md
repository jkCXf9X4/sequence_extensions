---
id: DR-021
title: Engine-core size budget with guardrail
summary: Engine core (flow + graph) budget raised to 5,000 lines and enforced by a guardrail test; growth must be justified, not silent
date: 2026-11-11
status: accepted
layers: [intent]
state: docs/breakdown/00-intent/vision.md
artifacts:
  - tests/test_package.py
supersedes: []
superseded_by: []
related: [INFO-001, IMP-024, IMP-025]
---

# DR-021: Engine-core size budget with guardrail

## Context

- Vision success criterion: "Package stays small: about 4,000 lines of engine core plus ext helpers" (`INFO-001`).
- Engine core (`flow` + `graph`) is 4,576 lines after committed features: plan pass, process pool, cancellation, runner.
- Growth is feature volume, not duplication; the dedup work removed the repeated patterns that remained.

## Decision

- Raise the core budget to 5,000 lines and enforce it: a guardrail test fails when `flow` + `graph` source exceeds the budget.
- Treat the budget as a soft ceiling: crossing it triggers a deliberate review, not an automatic refactor.

## Rationale

- The old criterion was unverifiable and already exceeded; silent drift is worse than an explicit, testable number.
- One test makes the success criterion executable; the split of `IMP-020` remains the release valve at the next major.

## Alternatives Considered

- Keep 4,000 lines: forces feature rejection or a premature split.
- No guardrail: the criterion stays aspirational and drifts.

## Consequences

- A new test in `tests/test_package.py` counts `flow` + `graph` source lines and asserts the budget.
- The vision criterion text is updated to match.

## Verification

- `tests/test_package.py::test_engine_core_size_budget`; full suite passes (469 tests).

## Review Trigger

- The budget is crossed; then either split (`IMP-020`) or revisit the number deliberately.