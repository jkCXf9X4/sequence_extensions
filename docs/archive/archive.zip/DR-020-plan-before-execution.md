---
id: DR-020
title: Plan-before-execution via construct-only plan pass
summary: A construct-only submit pass yields the pre-execution DAG and parameter surface; plan stays a read-only pre-pass, not a second execution model
date: 2026-11-11
status: accepted
layers: [intent, product]
state: docs/breakdown/00-intent/vision.md
artifacts:
  - src/sequence_extensions/flow/_plan.py
  - src/sequence_extensions/flow/run.py
supersedes: []
superseded_by: []
related: [INFO-001, IMP-023]
---

# DR-020: Plan-before-execution via construct-only plan pass

## Context

- Vision declared plan-before-execution structurally impossible with
  imperative submission (`INFO-001` out-of-scope).
- Non-programmers cannot visualize a predefined flow or tune its inputs: the
  graph exists only as it executes.

## Decision

- Accepted a build-mode plan pass (`IMP-023`): a composite body runs once with
  a construct-only `submit` — records the edge, never schedules — yielding the
  DAG and parameter surface; build stays a read-only pre-pass.
- The plan is plain data under one schema (`flow-plan/1`): document, manifest,
  override by node kind, diff (`CP-031` to `CP-035`); per-node values merge at
  submit from a node-name registry.

## Rationale

- The graph is already captured at construction: futures passed as arguments
  become edges. A construct-only submit exposes it without a new execution
  model.
- One JSON schema keeps the pre-run surface plain data: diffable, greppable,
  and readable without the code.

## Alternatives Considered

- Keep the "structurally impossible" line: non-programmers get no pre-run view.
- A separate DAG-description language: a representation users must learn,
  against the campaign-is-ordinary-Python commitment.

## Consequences

- Body runs twice (build, then execute); plan equals execution only for stable
  inputs.
- Fan-out expands only when the iterated list is concrete inside the body; a
  producer wrapped in a future collapses to one node.
- A direct heavy call inside a body (not via `submit`) runs during
  visualization.
- Node identity in the plan is positional; diffing across reorderings is an
  open strain tracked in `IMP-023`.

## Verification

- `tests/flow/test_plan.py`, `tests/flow/test_plan_document.py`; the full
  suite passes (461 tests).

## Review Trigger

- A second execution model or a second plan schema; node identity must become
  stable under reordering.