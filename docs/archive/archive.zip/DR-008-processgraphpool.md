---
id: DR-008
title: ProcessGraphPool — a process-pool executor for CPU-bound tasks
summary: A GraphPool subclass driving a ProcessPoolExecutor behind the existing pool= seam; workers buffer run-log records and the parent writes them at future completion
date: 2026-10-14
status: accepted
layers: [product, architecture, implementation, verification]
state: docs/breakdown/01-product/uc-22-run-cpu-bound-tasks-in-parallel.md
artifacts:
  - src/sequence_extensions/flow/process_pool.py
  - src/sequence_extensions/flow/task.py
  - src/sequence_extensions/flow/__init__.py
  - tests/flow/test_process_pool.py
  - CHANGELOG.md
supersedes: []
superseded_by: []
related: [DR-005, DR-007]
---

# DR-008: ProcessGraphPool — a process-pool executor for CPU-bound tasks

## Context

- `IMP-017`: flow parallelism is threads only; the GIL serializes CPU-bound task bodies.
- The `pool=` seam (`CP-021`) already accepts a caller-owned `GraphPool`; `DR-007` adds the `_submit_node` dispatch seam a subclass needs.
- A worker process cannot write the parent's `RunLog` (open file handle, not picklable).

## Decision

- `ProcessGraphPool(GraphPool)` in `flow/process_pool.py`: a `ProcessPoolExecutor` behind the same bind/result/exit surface, defaulting to the executor's CPU-count worker size.
- Flow tasks dispatch to a module-level runner carrying `(TaskFunction, run_info)`; dependencies resolve in the parent before dispatch.
- Workers buffer attempt records in a `TaskOutcome`; the parent replays them into the run log at future completion, before drain returns.
- Dispatch/transport failures wrap in `ProcessDispatchError`; the skip record's reason distinguishes them from dependency failures.

## Rationale

- Subclassing guarantees the surface `@flow(pool=...)` already checks; no flow-layer type gate changes.
- Parent-side record replay keeps one writer per run log — no cross-process file interleaving.
- The GIL wall is the measured pain: same campaign, same verdict, lower wall.

## Alternatives Considered

- Workers append to the shared JSON-lines file: rejected — record tearing across processes on large lines.
- A queue-based record crossing: rejected — replay at completion needs no extra plumbing.
- An `executor="process"` keyword on `@flow`: rejected — the `pool=` seam already exists.

## Consequences

- Positive: CPU-bound campaigns parallelize locally; retry, timeout, and audit semantics unchanged from the caller's view.
- Negative: tasks and payloads must be picklable; a task returning a `GraphFuture` works in thread mode only; nested `submit()` inside a worker is unsupported; timed-out attempts are abandoned in the worker process.

## Verification

- `tests/flow/test_process_pool.py`: results, dependency edges, retry and error record replay, skip records, dispatch failure, `TaskTimeoutError` across the boundary, flow end-to-end, CPU-bound wall-time gain.

## Review Trigger

- A requirement for nested submission inside process workers, or for a scheduler-native executor.
