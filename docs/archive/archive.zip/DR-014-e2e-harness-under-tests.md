---
id: DR-014
title: e2e harness under tests — versioned scratch, pinned run id
summary: The e2e harness moves under tests/e2e; its scratch (out/, one stable subtree per flow) is versioned instead of ignored, and the run id is pinned per flow so repeated runs leave only timing-field differences — no file churn
date: 2026-10-14
status: accepted
layers: [verification, implementation]
state: docs/breakdown/04-verification/testing.md
artifacts:
  - tests/e2e/flows.py
  - tests/e2e/test_flows.py
  - tests/e2e/README.md
  - tests/e2e/ref/campaign.jsonl
  - tests/e2e/ref/failing_campaign.jsonl
  - tests/e2e/out/logs/campaign-fixed.jsonl
  - tests/e2e/out/logs/failing_campaign-fixed.jsonl
  - pyproject.toml
supersedes: []
superseded_by: []
related: [DR-012, DR-013]
---

# DR-014: e2e harness under tests — versioned scratch, pinned run id

## Context

- `DR-013` placed the harness at `e2e/` with gitignored scratch, cleaned wholesale before each test.
- The owner asked for three refinements: move the folder under `tests/`, version the scratch (`out/`), and keep the run id stable so changes between test runs stay minimal.

## Decision

- The harness moves to `tests/e2e/`; `testpaths` returns to `["tests"]`; the `e2e/out` gitignore entry is dropped, so the scratch is versioned.
- The run id is pinned per flow (the tests patch the id builder to `<flow>-fixed`), so the log filename `out/logs/<flow>-fixed.jsonl` and the id inside every record are constant between runs.
- Scratch layout: one stable subtree per flow (`out/campaign/`, `out/failing_campaign/`), each cleaned per test (retry markers reset), plus shared stable-named logs; a full session leaves `out/` holding every flow's output.

## Rationale

- A pinned id removes the structural churn: no new-and-deleted log files per run, and a git diff between test runs touches only the volatile fields inside the logs — every artifact is byte-identical.
- Versioning the scratch makes the actual run output reviewable in a PR, beside the pinned reference it must match.
- One subtree per flow (not a wholesale wipe) is what makes the versioned tree complete: both flows' outputs survive a session, and the per-flow clean still resets the retry markers.

## Alternatives Considered

- Freeze clocks and thread names for byte-stable logs: rejected — three more private patches, fake durations, and the log stops being an honest execution record; `RunLog.diff` already compares robustly.
- Sanitized reference copies: rejected again (`DR-013`) — a second format; the raw log stays the reference.
- Keep `out/` ignored: rejected — the owner asked for the run output to be versioned; the pinned id makes that cheap.

## Consequences

- Positive: comparing versions is a plain `git diff` on `tests/e2e/ref` after regeneration (id-stable lines), and `out/` shows the latest run for inspection.
- Negative: test runs leave the working tree dirty in `out/` (timing fields in the logs); CI does not gate on git cleanliness, so this is cosmetic.
- The pinned id is a property of the e2e harness, not a product feature; real runs keep timestamped ids.

## Verification

- `tests/e2e/test_flows.py`: update run, then ten consecutive compare passes green; two full sessions tree-diffed — only the two log files differ, and the two runs' logs compare equal via `RunLog.diff`; full suite 267 tests; ruff clean.

## Review Trigger

- The scratch churn in reviews outweighs its inspectability, or a need for byte-stable logs (then revisit clock freezing with a stated policy).
