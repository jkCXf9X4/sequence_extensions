---
id: DR-017
title: One node primitive and explicit runs
summary: 3.0 replaces the @task/@flow split and global configuration with one @node primitive and execute_flow(node, options=RunOptions(...)); nested flows are child runs with parent linkage
date: 2026-10-21
status: accepted
layers: [product, architecture, implementation, verification]
state: docs/breakdown/02-architecture/flow-engine-decorators-over-the-graph-substrate.md
artifacts:
  - src/sequence_extensions/flow/_options.py
  - src/sequence_extensions/flow/_context.py
  - src/sequence_extensions/flow/node.py
  - src/sequence_extensions/flow/run.py
  - src/sequence_extensions/flow/runlog.py
  - src/sequence_extensions/flow/process_pool.py
  - src/sequence_extensions/flow_runner/__init__.py
  - tests/flow/test_node.py
  - tests/flow/test_run.py
  - tests/flow/test_options.py
  - tests/flow/test_process_pool.py
  - tests/runner/test_runner.py
  - tests/e2e/test_flows.py
supersedes: [DR-015]
superseded_by: []
related: [DR-005, DR-012, DR-016]
---

# DR-017: One node primitive and explicit runs

## Context

- 2.x split `@task` (policy, `.submit()`) from `@flow` (run identity, pool, log), conflating composition depth with the run boundary.
- A group of tasks needed a flow; an inner flow could not become a task (no `.submit()`, retries, timeout, parent linkage).
- A task body could submit in thread mode; it worked with spare workers and deadlocked at `max_workers=1`; a timed-out attempt could write after `run_end`.
- `Config`/`configure()` existed to reach decorators after import; with an explicit run entry point every run-level knob has a visible call site, and a global second source of truth hurts audit.

## Decision

- `@node` is the one primitive: policy plus `.submit()`; a body that calls/submits nodes is composite, with no extra decorator.
- `execute_flow(node, ..., options=RunOptions(...))` is the run boundary and returns a `Run`; failure raises with `.run`.
- `execute_flow` in a node body is a child run: own pool/log, parent linkage, and run retries/timeout make it a task unit.
- `.submit()` is driver-only; workers raise. Remove global config; `RunOptions.node_defaults` keeps per-run node tuning.
- Keep a thin TOML runner; schema 2 adds `path` and `parent_attempt`.

## Rationale

- The model matches composition as it works: tasks-from-tasks is a run, an inner flow used as a task is a child run.
- Separate child logs keep a sub-flow independently reproducible and runnable, with linkage in both directions; path records keep each run's audit local.
- Driver-only submit makes the old deadlock impossible by construction.
- Explicit options remove the import-order rule, the config ContextVar, and the three-way precedence burden.
- One primitive removes two names for one composition axis.

## Alternatives Considered

- One log, no child run identity: rejected — a retried composite's
  re-executed children need attempt-scoped identity, and a sub-flow
  loses its own account.
- Keep both decorators and add `.submit()` to `@flow`: rejected —
  two names for one composition axis, composite tasks still ambiguous.
- Keep `Config` alongside `RunOptions`: rejected — three ways to set a
  value, and config values are deliberately absent from the log.

## Consequences

- Breaking release: `@task`, `@flow`, `TaskFunction`, `TaskTimeoutError`,
  `last_run`, `__flow__`, and `config.py` are gone.
- Nested fan-out multiplies threads; child runs take explicit
  `max_workers`. `execute_flow` in a process worker is rejected.
- Timed-out attempts drop late records; the log never changes after
  `run_end`. The runner drives thread-mode runs only.
- Reference logs move to schema 2 and were regenerated deliberately.

## Verification

- `tests/flow/test_node.py` — policy, driver-only submit (including the
  old `max_workers=1` deadlock), dependency edges, late records.
- `tests/flow/test_run.py` — identity, drain, failure, nested linkage,
  child retries, run timeout, fixed ids, inheritance.
- `tests/flow/test_options.py`, `tests/flow/test_runlog*.py`,
  `tests/flow/test_process_pool.py` — options, schema 2, process mode.
- `tests/runner/test_runner.py`, `tests/e2e/` — runner and reference.

## Review Trigger

- Revisit if a user needs same-run concurrency from inside a worker
  (would require child pools or engine-declared composites), or if the
  thread multiplication of nested runs becomes an operational problem.
