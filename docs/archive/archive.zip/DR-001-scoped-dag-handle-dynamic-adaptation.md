---
id: DR-001
title: Scoped DAG handle for dynamic adaptation
summary: Dynamic adaptation uses a scoped DAG handle with a <scope> element; the declarative <branch>/<case> + Repeat() option is rejected.
date: 2026-10-09
status: accepted
layers: [architecture]
state: 02-architecture/workflow-engine.md
artifacts:
  - src/sequence_extensions/workflow/adaptation.py
  - src/sequence_extensions/workflow/schema.py
  - src/sequence_extensions/workflow/library.py
supersedes: []
superseded_by: []
related: [DR-002]
---

# DR-001: Scoped DAG handle for dynamic adaptation

## Context
- `INFO-001` design principle 2 (dynamic adaptation) requires actions to adjust downstream actions at runtime, scope-restricted, strictly downstream.
- The existing return-nodes protocol (functions emit new nodes replacing the next sibling group) is safe but cannot read the DAG, adjust existing actions, or copy actions to the end.
- The design space: give functions controlled DAG access while staying deterministic and scope-restricted.

## Decision
- On 2026-10-09, dynamic adaptation was adopted as a scoped DAG handle.
- Each adapting function receives a scoped view of the DAG and manipulates it; the engine applies changes transactionally.
- The `<scope type="...">` element unifies the grouping elements and names the adaptation boundary.
- The declarative `<branch>`/`<case>` + `Repeat()` option was rejected.

## Rationale
- The scoped handle adopts the paper's actual mechanism: functions manipulate the DAG as they run.
- Deterministic by construction: scoped view, transactional commit, read-only parallel children.
- It covers all paper patterns (per-file, scope, branching, iteration) with zero new schema constructs.
- The `<scope>` element makes the adaptation boundary explicit in the XML, addressing the paper's readability criticism.
- The grammar shrinks (two grouping elements become one), not grows.

## Alternatives Considered
- Declarative `<branch>`/`<case>` + `Repeat()`: rejected — adds control-flow schema constructs (a step toward a DSL), deviates from the paper's mechanism, grows the grammar.
- Return-nodes protocol (status quo): insufficient — cannot read the DAG, adjust existing actions, or copy to the end.

## Consequences
- Positive: all paper patterns covered with zero new schema constructs; deterministic by construction; adaptation boundary explicit in XML.
- Positive: backward compatible — the return-nodes protocol stays as a shortcut on the same internals.
- Negative: the engine must support runtime tree mutation (the lazy tree-walking engine, per `DR-002`).
- Negative: functions gain DAG access, requiring the adaptation contract to be documented.

## Verification
- The workflow test suite (`test_adaptation.py`, `test_engine.py`, `test_schema.py`) verifies the handle's read/write rules, scope restriction, read-only parallel children, and the `<scope>` alias strategy.
- `pb check --strict` validates this record.

## Review Trigger
- Revisit if the scoped handle proves insufficient for a paper pattern, or if the `<scope>` alias strategy causes confusion.
