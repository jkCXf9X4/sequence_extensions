---
id: DR-019
title: Stress-hardening pass — fail-safe settlement, iterative retries, canonical logs
summary: harden the engine against adversarial probes by settling every attempt, retrying iteratively, uniquely aliasing process nodes, canonicalizing strict logs, and counting repeated diff records
date: 2026-10-22
status: accepted
layers: [architecture, implementation, verification]
state: docs/breakdown/04-verification/stress-hardening-findings-and-dispositions.md
artifacts:
  - src/sequence_extensions/ext/list_ext.py
  - src/sequence_extensions/flow/node.py
  - src/sequence_extensions/flow/run.py
  - src/sequence_extensions/flow/runlog.py
  - src/sequence_extensions/flow_runner/__init__.py
  - src/sequence_extensions/graph/graph_future.py
  - tests/flow/test_hardening.py
  - tests/flow/test_runlog_tools.py
  - tests/e2e/ref/campaign.jsonl
  - tests/e2e/ref/failing_campaign.jsonl
supersedes: []
superseded_by: []
related: [DR-007, DR-012, DR-016, DR-018]
---

# DR-019: Stress-hardening pass

## Context

- Fork-isolated adversarial probes found two permanent hangs, a silent process-mode wrong-function bug, and determinism/audit holes.
- The hangs shared one cause: an attempt outcome could stay pending while drain waited on it.
- Zero-delay retries relied on Python recursion, so a large retry count livelocked at the recursion limit.
- Reference mode canonicalized record order but not nested key order; diff collapsed repeated identical work.

## Decision

- Settle every attempt unconditionally; a failed log write fails the attempt, never the drain.
- Drive retries in one iterative loop; callbacks and backoff timers start the next attempt on their own stack.
- Give every `NodeFunction` a unique pickle alias; wrap `BaseException` and settle the graph node.
- Canonicalize reference logs down to nested keys, emit strict JSON, and lock the fixed path against concurrent writers.
- Count repeated diff identities as a multiset with an `occurrence` index; expose `failed_nodes`; reject cross-pool binds.

## Rationale

- An audit engine may fail, but it must return; a pending outcome is a silent deadlock.
- A retry policy must be bounded by the configured count, not by the interpreter's stack limit.
- A qualname is not a unique process identity; the wrong function silently corrupts results and the log.
- Byte-identical reference files require canonical bytes, not only canonical record order.
- A green run verdict with an unlogged child failure is a trap for an audit-first tool.

## Alternatives Considered

- Always schedule zero-delay retries on a timer: rejected — one thread per retry, heavy at large counts.
- Keep last-wins diff: rejected — it cannot see a changed number of identical executions.
- Fail the run when any child fails: rejected — the root may deliberately handle a gathered error; `failed_nodes` keeps the root verdict while exposing the fact.
- Leave fixed-clock concurrency to the caller: rejected — the pinned path silently loses a log.

## Consequences

- Public additions: `Run.failed_nodes`, `run_end.failed_nodes`, `occurrence` in diff identities.
- Behavior changes: unbound `GraphFuture.result()` and `gather` outside a run raise; cross-pool bind raises; fixed-clock concurrent writers raise.
- `jsonable` output changes for non-finite floats, cyclic/deep containers, and colliding dict keys.
- Reference logs were regenerated; `tests/e2e/ref` carries the new `failed_nodes` field.
- A thread a node body starts still does not inherit the run context; documented as a limit.

## Verification

- `INFO-014` lists every finding, disposition, and regression test.
- `tests/flow/test_hardening.py` holds 40 regressions; the full suite is 398 tests at 92.7% coverage.
- `UPDATE_REF=1 pytest tests/e2e` regenerated the two reference logs.

## Review Trigger

- A new hang, a new process-pool identity form, or a reference-log schema change.
