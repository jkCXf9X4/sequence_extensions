---
id: DR-010
title: Use cases are need statements, not solution descriptions
summary: the eight use-case leaves (CP-016 to CP-023) re-authored solution-agnostic — scenario and acceptance in user-observable terms; API names, parameters, mechanisms, and code blocks move out to deliverables (INFO-002), architecture (INFO-003, INFO-011), and the API reference; IDs stable
date: 2026-10-14
status: accepted
layers: [product, architecture]
state: docs/breakdown/01-product/use-cases.md
artifacts:
  - docs/breakdown/01-product/use-cases.md
  - docs/breakdown/01-product/uc-16-define-a-flow-in-python.md
  - docs/breakdown/01-product/uc-17-run-independent-tasks-concurrently.md
  - docs/breakdown/01-product/uc-18-order-dependent-tasks-general-dag.md
  - docs/breakdown/01-product/uc-19-retry-back-off-and-bound-a-task.md
  - docs/breakdown/01-product/uc-20-audit-a-run.md
  - docs/breakdown/01-product/uc-21-bound-the-concurrency.md
  - docs/breakdown/01-product/uc-22-run-cpu-bound-tasks-in-parallel.md
  - docs/breakdown/01-product/uc-23-run-flows-concurrently-in-one-process.md
  - docs/breakdown/02-architecture/flow-engine-decorators-over-the-graph-substrate.md
  - docs/breakdown/01-product/README.md
supersedes: []
superseded_by: []
related: [DR-005, DR-006, DR-009]
---

# DR-010: Use cases are need statements, not solution descriptions

## Context

- The use-case leaves carried `## API` sections (code blocks, decorator, parameter, and class names) and mechanism-level acceptance (`pool-scoped cancellation`, `TaskTimeoutError`, pickling contract, record replay).
- Use cases live in the product layer to state what users need; the solution's shape belongs to the deliverables (shipped surface), the architecture (mechanisms), and the implementation (code and tests).
- `DR-006`: the tree holds current state only, each fact in exactly one place.

## Decision

- Every use-case leaf (`CP-016` to `CP-023`) re-authored, IDs and filenames stable: Scenario states actor, goal, context; Acceptance states user-observable outcomes; `## API` sections removed.
- Evidence sections keep their pytest identifiers: they are verification anchors, not solution description.
- Each leaf's Excludes points to where the need is met: `INFO-002` (shipped surface), `INFO-011` (engine design).
- No fact lost: every removed solution fact verified present in the deliverables, the architecture leaves, or the API reference; missing bits added there.
- Boundary: the intent layer may name the product (the vision frames the solution); use cases may not.

## Rationale

- A use case stated in API terms cannot survive an API change and hides the need it serves.
- Need-level acceptance is checkable by observation (wall time, record completeness, interference-freedom) without reference to implementation.

## Alternatives Considered

- Move the use cases to the intent layer: rejected — they are the product's requirement set, not its motivation.
- Move evidence to the testing leaf: rejected — leaf-level verification anchors would be lost.
- Keep API sections as fulfillment examples: rejected — the same content already lives in `INFO-002` and the API reference; duplication drifts.

## Consequences

- Positive: need and solution are separable; API changes now touch the deliverables and architecture leaves, not the catalog.
- Negative: acceptance statements are less prescriptive; the how lives in `INFO-011` and the API reference.

## Verification

- Token sweep: no API identifiers (decorator, parameter, class names) in Scenario, Acceptance, or summary of `01-product/uc-*.md`; Evidence sections exempt.
- `pb check --strict` and `pb node-size --strict` green; registers regenerated; every citation resolves.

## Review Trigger

- A use-case leaf needs an API name to state its acceptance, or the catalog grows a solution-shaped row.
