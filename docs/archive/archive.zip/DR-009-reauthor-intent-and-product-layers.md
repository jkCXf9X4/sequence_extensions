---
id: DR-009
title: Re-author intent and product layers around the shipped direction
summary: Vision and use-case catalog still carried consolidation-era framing and supersession narrative; re-authored to lead with parallel, deterministic, audited execution — local or at HPC — with audit as the trust mechanism; CP-023 (concurrent flows) added to the catalog
date: 2026-10-14
status: accepted
layers: [intent, product]
state: docs/breakdown/00-intent/vision.md
artifacts:
  - docs/breakdown/00-intent/vision.md
  - docs/breakdown/00-intent/README.md
  - docs/breakdown/01-product/use-cases.md
  - docs/breakdown/01-product/uc-23-run-flows-concurrently-in-one-process.md
  - docs/breakdown/01-product/deliverables.md
  - README.md
  - docs/API.md
  - pyproject.toml
supersedes: []
superseded_by: []
related: [DR-005, DR-006, DR-007, DR-008]
---

# DR-009: Re-author intent and product layers around the shipped direction

## Context

- `INFO-001` and `INFO-010` were authored for the `DR-005` consolidation and still carried its framing: an Origin section, supersession verbs, and the previous-catalog note.
- The direction settled since: parallelism local or at HPC and deterministic operations (`DR-007`, `DR-008`, release 1.1.0).
- `DR-006`: the tree holds current state only; history lives in the archive.
- Concurrent flows in one process shipped with `DR-007` (pool-scoped cancellation), test-evidenced, but had no use-case leaf.

## Decision

- `INFO-001` re-authored, ID stable: leads with parallel, deterministic, audited execution — local or at HPC; audit is the trust mechanism; history narrative removed (Origin section, `DR-005` pointers).
- `INFO-010` re-authored, ID stable: supersession note dropped; `CP-023` added.
- `CP-023` filed: run flows concurrently in one process; evidence from the 1.1.0 suite.
- Identity surfaces aligned to the same lead: README pitch and section leads, API docs leads, breakdown README, `flow` docstring, package description.
- Out-of-scope statements restated as current boundaries; supersession wording leaves the tree (`DR-005` stays an archive record).

## Rationale

- The vision is the first leaf read; it should state the product's current promise, not the transition that produced it.
- A shipped, evidenced capability without a catalog row is invisible to the product layer.
- One identity sentence across all surfaces keeps `INFO-001`, the README, and the package description from diverging.

## Alternatives Considered

- Keep the consolidation framing: rejected — history narration in leaves violates `DR-006`.
- New IDs for the re-authored leaves: rejected — citation churn for a content change.
- Drop the flow-engine identity entirely: rejected — the change is emphasis and order, not vocabulary; audit-first remains the trust mechanism.

## Consequences

- Positive: intent layer states the direction in the author's terms; catalog complete for 1.1.0; identity coherent across every surface.
- Negative: none identified; all citations kept resolving (IDs stable, `CP-023` created before the catalog cites it).

## Verification

- `pb check --strict` and `pb node-size --strict` green; registers regenerated (index rows sync the new summaries).
- Full test suite green after the `flow` docstring touch.

## Review Trigger

- The vision's lead changes again (a new capability family), or a surface drifts from `INFO-001`.
