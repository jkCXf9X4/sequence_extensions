---
id: DR-011
title: Deliverables live in architecture; the product layer is needs only
summary: INFO-002 (the shipped-surface listing) relocated from 01-product to 02-architecture, completing the needs/solution split — the product layer answers only what users need; layer questions and README prose restated
date: 2026-10-14
status: accepted
layers: [product, architecture]
state: docs/breakdown/02-architecture/deliverables.md
artifacts:
  - docs/breakdown/02-architecture/deliverables.md
  - docs/breakdown/01-product/README.md
  - docs/breakdown/02-architecture/README.md
  - docs/breakdown/README.md
supersedes: []
superseded_by: []
related: [DR-006, DR-010]
---

# DR-011: Deliverables live in architecture; the product layer is needs only

## Context

- `DR-010` made the use-case leaves need statements; solution material moved to the solution leaves.
- `INFO-002` (deliverables — the shipped-surface listing) still lived in `01-product`, so the layer held solution material in leaf form after its content became needs-only.
- An owner edit relocated the leaf from `01-product/` to `02-architecture/` in the working tree; this record adopts and completes that move.

## Decision

- `INFO-002` lives in `02-architecture`.
- The layer questions restated: `01-product` answers what users need; `02-architecture` answers what is delivered and how it is organized.
- Layer README prose and the root layer map updated to the restated questions; registers regenerated.

## Rationale

- A needs-only layer cannot hold the shipped-surface listing; placement must match the split `DR-010` made in content.
- Citations are by stable ID (`INFO-002`), so the relocation costs nothing downstream.

## Alternatives Considered

- Keep `INFO-002` in `01-product`: rejected — contradicts the needs-only scope.
- Split the leaf, keeping its out-of-scope part in `01-product`: rejected — scope boundaries already live in `INFO-001`; one fact, one home.

## Consequences

- Positive: the layer ladder is a clean needs-then-solution chain — intent (why), product (needs), architecture (delivered surface and design).
- Negative: none identified; every `INFO-002` citation resolves unchanged.

## Verification

- `pb check --strict` and `pb node-size --strict` green; registers regenerated.

## Review Trigger

- A leaf's placement contradicts its layer question.
