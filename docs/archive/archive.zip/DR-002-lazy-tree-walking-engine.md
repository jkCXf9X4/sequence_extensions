---
id: DR-002
title: Lazy tree-walking engine for dynamic adaptation
summary: The workflow engine is a lazy tree-walking interpreter; runtime adaptation mutates the live node tree through a scoped DAGHandle with transactional commit.
date: 2026-10-09
status: accepted
layers: [architecture]
state: 02-architecture/workflow-engine.md
artifacts:
  - src/sequence_extensions/workflow/engine.py
  - src/sequence_extensions/workflow/adaptation.py
supersedes: []
superseded_by: []
related: []
---

# DR-002: Lazy tree-walking engine for dynamic adaptation

## Context
- The eager engine compiles the whole tree to futures up front; runtime changes to downstream nodes are impossible.
- `IMP-001` needs actions to add, replace, and adjust downstream nodes at runtime — strictly downstream, at-most-once, deterministic.
- Open question: which engine shape supports that without a cancellation or reconciliation layer.

## Decision
- On 2026-10-09 the engine was chosen as a LAZY TREE-WALKING INTERPRETER: walk the tree child by child, one `GraphFuture` per action.
- The node tree is the mutable DAG; functions mutate it through a scoped `DAGHandle` with transactional commit at return.
- `graph/graph_future.py` stays frozen; the walker is a new consumption pattern of it.

## Rationale
- The walker re-reads the live tree after every step; runtime splices are observed immediately, no reconciliation.
- The sequential invariant: while an action runs, its following positions are unwalked.
- So handle writes land only on nodes with no future yet — structural, not conventional.
- Parallel parents get read-only handles; the F4 race is resolved structurally.
- At-most-once and bounded adaptation (10 000 dynamic nodes) keep runs deterministic and terminate runaways.

## Alternatives Considered
- Keep the eager engine and add reconcile hooks after each step — rejected: a second source of truth; the race the handle removes returns.
- Functions return a patch the engine applies — rejected: the patch is a copy, not the live tree; the live tree as single mutable DAG is simpler.

## Consequences
- Positive: runtime adaptation is a plain tree edit; the walker observes it by re-reading. No cancellation machinery.
- Positive: the sequential invariant and read-only parallel handles make the F4 race structurally impossible.
- Negative: the engine rewrite is large; the 295-test suite is the parity gate.
- Negative: parallel-group children run on plain threads (bounded by workflow structure), not pool workers.

## Verification
- The 295-test workflow suite is the parity gate.
- A barrier-based test pins that a `Parallel` group's children start concurrently (a serializing walker deadlocks).
- `pb check --strict` validates this record and the `INFO-004` leaf.

## Review Trigger
- Revisit if the graph substrate is deemed internal-only (slimming it is a separate pass), or if the 10 000-node bound proves wrong for real workflows.
