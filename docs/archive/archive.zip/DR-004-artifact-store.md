---
id: DR-004
title: By-reference artifact store coupled to the DAG
summary: Bulk workflow data flows through an opt-in ArtifactStore with minted addresses and an append-only manifest; the structured results-kwarg and blackboard options are rejected.
date: 2026-10-11
status: superseded
layers: [architecture]
state: 02-architecture/workflow-artifacts-by-reference-data-plane.md
artifacts:
  - src/sequence_extensions/workflow/artifacts.py
  - src/sequence_extensions/workflow/engine.py
  - src/sequence_extensions/workflow/registry.py
  - src/sequence_extensions/workflow/history.py
supersedes: []
superseded_by: [DR-005]
related: [DR-001, DR-002]
---

# DR-004: By-reference artifact store coupled to the DAG

## Context
- The engine's data plane is by value: results flow through kwargs, so bulk payloads (simulation outputs, reports, datasets) are carried by the result chain and echoed into history's recorded parameters — measured to roughly double per clone in sweep/iteration chains (`IMP-005`).
- Files a function writes are invisible to the engine and history: no addressing, no evidence, no replay.
- `INFO-001` requires traceable and reproducible runs; the evidence story stops at result values.

## Decision
- On 2026-10-11, a by-reference artifact store was adopted (`IMP-005` option 4).
- Control data keeps flowing by value through kwargs; artifacts flow by reference and never enter kwargs.
- The store is opt-in (`run_workflow` / `Test_Framework` take `artifacts=ArtifactStore(root)`; absent means zero behavior change) and couples to the schema only, never the engine.
- Every executed action mints a directory address at submission time (scope labels plus function name, collision suffixes on repeat) recorded in an append-only manifest; addresses are never recomputed.
- Functions that declare an `artifacts` parameter receive a scoped handle: writes to the node's own directory, reads scope-checked to the causal past, fan-in enumeration of completed parallel groups' branches.
- The structured `results=` kwarg and the ordering-decoupled blackboard were rejected.

## Rationale
- The split keeps the paper's call contract intact: paper listings run verbatim, results unchanged.
- Addresses minted at call time survive dynamic adaptation (positions shift; addresses never move) — the same identity-at-call-time pattern as history's `group_path`.
- The read scope mirrors the kwargs fan-in by construction (the walker threads the readable past alongside the chain), so parallel barriers and causal reads inherit the walker's determinism argument without a new invariant.
- The manifest records only an action's own params, never merged kwargs: the reference plane cannot compound the echo problem it exists to relieve.

## Alternatives Considered
- Structured `results=` kwarg (a second reserved data channel): rejected — touches the paper's flat call contract, no disk story, and leaves addressing unsolved.
- Blackboard decoupled from ordering: rejected — requires proving no read-before-write under concurrency; the merge negotiation the paper reports as its main complexity source.
- Status quo plus documentation: rejected — payload growth is measured, not hypothetical; the evidence gap stays.

## Consequences
- Positive: bulk payloads stop flowing through kwargs and history; every run has an addressable, externally readable evidence tree; cross-branch comparison (fan-in) reaches data kwargs deliberately do not carry.
- Positive: replay extends to artifacts — `ReplayArtifacts` serves reads from the manifest and re-derives identical pointers.
- Negative: the engine walk carries addressing state (mint counters, label counters, the readable past) alongside the chain.
- Negative: manifest global sequence numbers interleave across concurrently walked parallel branches (addresses and entry sets remain deterministic).

## Verification
- `tests/workflow/test_artifacts.py` (34 tests) verifies the opt-in contract, minted addresses and suffix series, manifest contents, causal-past reads, parallel barriers, fan-in branch enumeration, sweep/return-nodes clone addressing, history linkage, and replay.
- The full suite (433 tests) passes; `ruff check` clean; `pb check --strict` validates this record.

## Review Trigger
- Revisit if comparison tooling or content hashes (IMP-005 phase 3) need manifest entry shapes beyond mint-time fields, or if library functions should adopt the pointer convention (the open echo-contract decision D5).
