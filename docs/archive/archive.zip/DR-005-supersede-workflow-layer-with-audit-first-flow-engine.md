---
id: DR-005
title: Supersede the workflow layer with an audit-first flow engine
summary: The declarative workflow layer (XML schema, node tree, adaptation, artifact store, replay) is superseded by @task/@flow decorators over graph_future with a JSON-lines run log as the product
date: 2026-10-13
status: accepted
layers: [intent, product, architecture, implementation, verification, operation]
state: docs/breakdown/02-architecture/flow-engine-decorators-over-the-graph-substrate.md
artifacts:
  - src/sequence_extensions/flow/
  - tests/flow/
supersedes: [DR-001, DR-002, DR-004]
superseded_by: []
related: []
---

# DR-005: Supersede the workflow layer with an audit-first flow engine

## Context

- The workflow layer realized the paper's XML schema, node tree, adaptation, artifact store, and replay: 7,104 lines of a 9,091-line package.
- Requirements distilled to parallelism (local, HPC-extendable), deterministic operations, and audit of what happened.
- A four-engine benchmark (this package, Prefect, Snakemake, cwltool) ran one identical campaign; all four produced the identical verdict.
- The schema fully owned 2 of 15 use cases; the paper's readability claim rests on one hedged sentence (its §4.4).

## Decision

- Superseded the workflow layer; replaced it with the flow layer: `@task` (retries, backoff, timeout), `@flow` (run identity, pool, run log), JSON-lines audit log.
- Kept `graph.graph_future` and `ext` unchanged.
- Removed XML schema and templates, node tree and scoped handles, adaptation, function library and registry, artifact store, replay, engine, and CLI.

## Rationale

- The XML's engineer-readability premise was never demonstrated; developers are the accepted audience.
- Adaptation existed to restore loops to a loop-free format; Python has loops.
- The artifact store solved three tree-caused problems; without the tree they do not arise.
- Audit outranks replay: git-pinned code plus the run log reproduce what happened.

## Alternatives Considered

- Keep the layer; fix composition friction (one-level result surfacing, fan-in through the artifact store).
- Adopt Prefect or Snakemake instead of an own engine.

## Consequences

- Positive: package drops from 9,091 to about 1,900 lines; general DAGs replace series-parallel trees; retry and timeout become task attributes; the audit log is a first-class product.
- Negative: plan-before-execution (dry run) is structurally gone; non-programmer authoring is gone; replay is gone.

## Verification

- `tests/flow/test_acceptance.py` runs the benchmark campaign: identical verdict, 7 attempts, 15 log records.
- Suite green: 222 tests; coverage 95.9 percent.

## Review Trigger

- A requirement returns for plan inspection before execution, or for non-programmer workflow authoring.
