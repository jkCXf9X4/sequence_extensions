---
id: DR-018
title: Compose with nodes, not nested runs
summary: remove child runs; a node tree is one run and one log, submitted composites return futures, and gather combines them without blocking a worker
date: 2026-10-21
status: accepted
layers: [product, architecture, implementation, verification]
state: docs/breakdown/02-architecture/flow-engine-decorators-over-the-graph-substrate.md
artifacts:
  - src/sequence_extensions/flow/_context.py
  - src/sequence_extensions/flow/_options.py
  - src/sequence_extensions/flow/node.py
  - src/sequence_extensions/flow/run.py
  - src/sequence_extensions/flow/runlog.py
  - src/sequence_extensions/flow/process_pool.py
  - src/sequence_extensions/graph/graph_future.py
  - tests/flow/test_nested.py
  - tests/flow/test_node.py
  - tests/flow/test_run.py
  - tests/flow/test_options.py
  - tests/flow/test_process_pool.py
  - tests/flow/test_runlog_tools.py
supersedes: []
superseded_by: []
related: [DR-005, DR-012, DR-016, DR-017]
---

# DR-018: Compose with nodes, not nested runs

## Context

- `DR-017` introduced child runs: `execute_flow` inside a node body opened a second run with its own pool, log, and parent linkage.
- A composite node already has a policy and an audit path; a child run duplicated that model and added child ids, option inheritance, `children` links, and tree diffing.
- The reason for driver-only `.submit()` was the bounded-pool deadlock.  A child run worked around it by giving the composite a fresh pool, not by removing the wait.
- Graph futures already express fan-out as a dependency graph: a function may return another future, and the graph forwards its result without holding the worker.

## Decision

- Remove child runs; `execute_flow` is top-level only; one run/pool/log; `path`/`parent_attempt` carry nesting.
- A node may return a value or a future; the attempt settles on completion and frees its worker.
- A worker may submit; blocking on an incomplete future raises; `gather` combines results.
- Graph dependencies accept plain `concurrent.futures.Future` values as well as `GraphFuture`.
- Remove parent/children fields, child ids/inheritance, and `follow_children` from the log and diff.
- Process workers cannot submit or return futures; process-mode fan-out is parent-only.

## Rationale

- Composition is node nesting; a second run identity is not needed to call a sub-workflow.
- Future-first fan-out removes the deadlock instead of isolating it: no worker waits, so the run's pool is never starved, even at `max_workers=1`.
- One log keeps the audit of a run local and makes `path`/`parent_attempt` the single nesting account.
- Composite retry/timeout still work because the attempt settles on the returned future.

## Alternatives Considered

- Keep child runs for separate sub-flow logs: rejected — separate logs
  duplicate the audit and add linkage/diff machinery; a host can run a
  sub-workflow on its own with a top-level `execute_flow`.
- Scoped nested pool per composite: rejected — it isolates the wait but
  still halts a worker; futures avoid the wait entirely.
- Driver-only submit with inline-only composites: rejected — a submitted
  composite could not fan out concurrently.

## Consequences

- Breaking 3.0 change: child runs, parent linkage, `children`,
  `follow_children`, and child option inheritance are gone.
- A node returning a container of futures is rejected; use `gather`.
- A timed-out composite attempt drops late records from its abandoned
  subtree through the attempt-token ancestor chain.
- Process-mode fan-out is parent-only; process workers remain
  inline/sequential.
- Reference logs remain schema 2 but no longer carry child-run fields;
  reference files were regenerated.

## Verification

- `tests/flow/test_nested.py` — node nesting, future-first fan-out at
  `max_workers=1`, inline fan-out, gather + dependent node, composite
  retry/timeout/failure, fixed-clock determinism.
- `tests/flow/test_node.py` — worker submit, blocking guard, policy.
- `tests/flow/test_run.py` — one log for nested nodes, paths, defaults.
- `tests/flow/test_runlog_tools.py` — flat diff only.
- `tests/flow/test_process_pool.py` — process worker rejection.

## Review Trigger

- Revisit if future-first composition cannot express a required workflow, or if a separate sub-flow log becomes a hard requirement.
