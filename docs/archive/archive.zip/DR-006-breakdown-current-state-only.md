---
id: DR-006
title: Breakdown holds current state only; completed IMPs retire into the archive
summary: The breakdown tree keeps current state and open candidates only — completed IMPs leave the tree as archive tombstones, and committed choices live as archive records
date: 2026-10-14
status: accepted
layers: [operation]
state: README.md
artifacts:
  - docs/archive/archive.zip
  - docs/breakdown/06-evolution/README.md
  - docs/breakdown/06-evolution/roadmap.md
  - docs/breakdown/05-operation/running-flows-local-and-at-hpc.md
supersedes: []
superseded_by: []
related: [DR-003, DR-005]
---

# DR-006: Breakdown holds current state only; completed IMPs retire into the archive

## Context

- `DR-003` parked completed IMPs in `06-evolution/implemented/` — untracked, but inside the state tree.
- After `DR-005`, all fifteen such IMPs describe the superseded workflow layer.
- A browsing agent globbing the tree still met old-direction prose.

## Decision

- The breakdown tree holds current state and open candidates only.
- A completed IMP leaves the tree on completion, archived as a tombstone via `pb archive add --deprecated`.
- Committed choices are archive records; the tree never carries them.

## Rationale

- A file in the tree reads as live to a browsing agent, tracked or not.
- History already has one home: the cold-storage archive.
- Old-direction material in the tree costs every future read.

## Alternatives Considered

- Keep `implemented/` untracked, per `DR-003`: rejected — still globbable, still reads as current.
- Delete the completed IMPs outright: rejected — the investigations remain consultable context.

## Consequences

- Positive: `docs/breakdown/` is current state plus open candidates; nothing else.
- Positive: the IMP lifecycle ends at the archive; no second resting place.
- Negative: the tree alone no longer shows what was done — history is two commands away (`pb archive list`, `pb archive read`).

## Verification

- `pb archive list --deprecated` lists the fifteen retired IMPs beside the earlier tombstones.
- `pb check --strict` and `pb node-size --strict` pass on the cleaned tree.

## Review Trigger

- A need to browse completed work without the archive tool.
