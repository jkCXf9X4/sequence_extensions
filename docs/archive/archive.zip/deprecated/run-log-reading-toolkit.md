---
id: IMP-022
type: imp
title: Run-log reading toolkit
summary: RunLog.records is a one-shot full read; filter, summarize, and run-diff helpers would make determinism checkable — same code and inputs must produce semantically equal logs
date: 2026-10-14
status: current
---

# Run-log reading toolkit

Candidate, not selected. Filed from the 2026-10-14 functionality
evaluation; implemented on owner demand only.

## Pain

- The log is the executed truth (`CP-020`); `INFO-001` names it
  diffable and greppable as a success criterion.
- The only reading API is `RunLog.records` — a one-shot full parse,
  no filtering, no summary, no comparison.
- Verifying determinism (same code and inputs, same execution) today
  means hand-written ad-hoc scripts per user.

## Proposal

- Read-side helpers beside `records`:
  - `filter` — records by kind, task, status, attempt.
  - `summarize` — per task: attempts, statuses, wall time; the run
    verdict.
  - `diff` — two runs compared semantically: which attempts differ,
    what is missing or extra.
- Diff keys on (task, attempt), not raw `seq`; timing fields
  (start, end, duration, worker) excluded by default — wall time is
  not a determinism claim.
- Output is jsonable and stably ordered; `records` itself unchanged.

## Cost

- One module of pure read-side code plus tests; no writer changes,
  no new dependencies, `SCHEMA_VERSION` untouched.
- Diff rules are policy (what counts as equal) and must be stated,
  not discovered by users.

## Evidence

- `INFO-001` success criteria: the log is diffable, greppable,
  readable without the code beside it.
- Complements `IMP-018` (the payload tier writes; this reads).
