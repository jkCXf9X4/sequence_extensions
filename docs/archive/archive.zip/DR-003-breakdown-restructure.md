---
id: DR-003
title: Breakdown restructure: decision archive, references, implemented IMPs
summary: The breakdown keeps history in the cold-storage archive docs/archive/archive.zip with generated registers beside it; the source paper lives in docs/references/.
date: 2026-10-10
status: accepted
layers: [operation, intent]
state: README.md
artifacts:
  - docs/breakdown/pb.toml
  - docs/archive/archive.zip
  - docs/references/paper_44_yBqbPyj1.pdf
  - docs/breakdown/06-evolution/implemented/dynamic-adaptation.md
supersedes: []
superseded_by: []
related: [DR-001, DR-002]
---

# DR-003: Breakdown restructure: decision archive, references, implemented IMPs

## Context
- The breakdown kept history as a loose `decisions/` stream beside the state tree; browsing agents could glob stale records.
- The source paper sat inside the state tree at `00-intent/paper_44_yBqbPyj1.pdf`; reference material is not state.
- `IMP-001` was complete (design implemented via `DR-001` and `DR-002`) but still sat in the evolution layer as an open investigation.

## Decision
- On 2026-10-10 the breakdown was restructured: history moved to the cold-storage archive `docs/archive/archive.zip`, reached only via `pb archive` add/read/list.
- The generated registers moved beside the archive at `docs/archive/` (`README.md`, `design-choice-log.md`, `traceability-map.md`); `pb.toml` `[registers]` points there.
- The source paper moved to `docs/references/paper_44_yBqbPyj1.pdf`, outside the state tree.
- `IMP-001` moved to `06-evolution/implemented/dynamic-adaptation.md`; no longer tracked.

## Rationale
- Cold storage quarantines history: stale records cannot pollute a browsing agent's context.
- One home per fact: reference material, state, and history each get a distinct surface.
- A completed IMP is history, not a candidate; the evolution layer holds candidates only.
- The registers beside the archive keep the generated index, log, and map together with their source.

## Alternatives Considered
- Keep the loose `decisions/` stream: rejected — stale records stay globbable; no cold storage.
- Keep the paper in `00-intent/`: rejected — reference material inside the state tree blurs the state/history boundary.
- Delete the completed `IMP-001` file: rejected — the investigation is a historical record of what was done.

## Consequences
- Positive: history is cold, state is clean; `pb doctor` resolves the archive and its entry counts.
- Positive: the empty `docs/breakdown/decisions/` directory stays for root discovery; no loose records remain.
- Negative: records are reachable only via `pb archive`; a reader without the tool cannot browse history.
- Negative: the registers live outside the breakdown root; tooling must resolve them from the archive's parent.

## Verification
- `pb doctor` shows the resolved archive path and entry counts.
- `pb check --strict` validates the tree; `pb registers` (archive mode) rebuilds the three registers from the archive.
- `pb archive list` and `pb archive read` resolve every record by ID.

## Review Trigger
- Revisit if the archive proves too cold for routine access, or if registers beside it confuse root discovery.
