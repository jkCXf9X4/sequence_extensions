---
id: DR-015
title: External configuration and flow-runner — TOML config, per-call resolution, module-scan discovery
summary: Engine parameters resolve per call from a TOML Config installed by configure() — explicit keyword > config > built-in default — and flow-runner launches a flow by scanning [run].module for the __flow__ marker
date: 2026-10-16
status: accepted
layers: [product, architecture, implementation, verification, operation]
state: docs/breakdown/02-architecture/flow-engine-decorators-over-the-graph-substrate.md
artifacts:
  - src/sequence_extensions/config.py
  - src/sequence_extensions/flow_runner/__init__.py
  - src/sequence_extensions/flow_runner/__main__.py
  - src/sequence_extensions/flow/task.py
  - src/sequence_extensions/flow/flow.py
  - src/sequence_extensions/flow/process_pool.py
  - src/sequence_extensions/graph/graph_future.py
  - src/sequence_extensions/flow/__init__.py
  - tests/flow/test_config.py
  - tests/runner/flows.py
  - tests/runner/test_runner.py
  - docs/API.md
  - README.md
  - CHANGELOG.md
supersedes: []
superseded_by: []
related: [DR-005, DR-008, DR-012]
---

# DR-015: External configuration and flow-runner — TOML config, per-call resolution, module-scan discovery

## Context

- Parameters lived only in decorator keywords; every tuning change was a code change (`INFO-011`).
- Operators needed to pick a flow, set its inputs, and tune the engine without writing Python.
- Zero runtime dependencies was a locked property (`INFO-005`).

## Decision

- Added `sequence_extensions.config`: frozen validated `Config` dataclasses for `[flow]`, `[task]`, `[pool]`, `[run]`, `[inputs]`; `from_toml` / `from_dict` loaders; strict (unknown keys and bad values fail at load, message names file, section, key).
- Precedence per parameter: explicit decorator keyword > active config > built-in default. Resolution at call time, so `configure()` after import reaches module-level decorators.
- Raised the Python floor 3.9 to 3.11: stdlib `tomllib` reads the file; the zero-dependency claim holds. Released as 2.0.0.
- Added `flow-runner` (console script and `python -m` entry): load config, `configure`, import `[run] module`, scan for the `__flow__` marker, validate `[inputs]` against the flow signature, call. Exit codes 0 ok, 1 flow failure, 2 usage or config error.
- Config travels the threading model: pool workers and timeout attempt threads restore the config `ContextVar` (same plumbing as the run context); process mode resolves policy in the submitting thread and ships concrete values, because executor dispatch pickles from its manager thread.

## Rationale

- Call-time resolution is the only import-order-independent contract: `configure()` in `main()` must reach module-level decorators.
- Keyword-first precedence keeps every existing program valid: a config only fills gaps, never overrides.
- Module scan needs no registration call and no global registry; the marker is stamped by the decorator itself.
- TOML on 3.11 is the only stdlib format with comments and structured values.

## Alternatives Considered

- JSON config: rejected — no comments, weaker hand-editing.
- Environment variables only: rejected — flat, stringly typed, no structured inputs.
- An explicit flow registry: rejected — global state plus registration ceremony; the module scan is implicit and collision-free.
- Explicit pass-through only (`@flow(**cfg.flow)`): rejected — every call site stays code; config cannot reach module-level decorators.

## Consequences

- Positive: one TOML file tunes the engine, selects a flow, and sets inputs (`CP-026`); cron, CI, and SLURM drive flows by exit code; existing programs unchanged (defaults identical, e2e reference byte-identical).
- Negative: Python 3.9 and 3.10 dropped (breaking, 2.0.0); pools constructed directly resolve at construction time (ordering constraint, documented); `[inputs]` limited to TOML-expressible values; a config file names a module to import, so it is trusted code.

## Verification

- `tests/flow/test_config.py`: loading, strictness, precedence (explicit > config > default), call-time resolution after import, thread and attempt-thread restoration, process-pool resolution, `""` disables log, pool construction defaults, `last_run` shape.
- `tests/runner/test_runner.py`: selection, `--list`, `--flow`, signature validation, exit codes 0/1/2, `python -m` subprocess entry.
- `tests/e2e`: no config installed — reference logs unchanged.

## Review Trigger

- A need for per-task data arguments in `[inputs]`, or non-TOML runner inputs.
