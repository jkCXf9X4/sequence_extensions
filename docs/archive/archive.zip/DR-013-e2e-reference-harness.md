---
id: DR-013
title: e2e reference harness — version comparison by RunLog.diff
summary: Two deterministic mock flows (e2e/flows.py) run against a committed reference (e2e/ref) of logs and artifact trees; RunLog.diff is the comparison, UPDATE_REF regenerates, and a failure means behavior changed between versions
date: 2026-10-14
status: accepted
layers: [verification, implementation]
state: docs/breakdown/04-verification/testing.md
artifacts:
  - e2e/flows.py
  - e2e/test_flows.py
  - e2e/README.md
  - e2e/ref/campaign.jsonl
  - e2e/ref/failing-campaign.jsonl
  - pyproject.toml
supersedes: []
superseded_by: []
related: [DR-005, DR-012]
---

# DR-013: e2e reference harness — version comparison by RunLog.diff

## Context

- The owner asked for an end-to-end pair: two flows in a separate module, tests running them, and a committed reference directory so logs and artifacts can be compared between versions.
- `DR-012` shipped `RunLog.diff` — the semantic two-run comparison — but nothing in the suite pinned a run as a reference for later versions to be checked against.

## Decision

- `e2e/` is a package: `flows.py` (two mock flows — a retrying fan-out pipeline with a verdict artifact, and a failing one with dependency skips), `test_flows.py` (one test per flow), committed `cases/` and `ref/`; scratch in gitignored `e2e/out/`, cleaned per test.
- Comparison: `RunLog.diff` over the logs with `DIFF_EXCLUDE` plus the `version` field (metadata, not behavior) and byte-for-byte artifact comparison over the same file set; `testpaths` grows `e2e`, so CI enforces it on 3.9–3.13.
- `UPDATE_REF=1 python -m pytest e2e` regenerates the reference after an intended change; a failure prints the pinpointing diff report.

## Rationale

- The engine proves its own claim: the gate is `RunLog.diff`, the same check users run — no parallel comparison format to keep honest.
- Raw logs and real artifact files in the reference stay greppable and human-inspectable; nothing is normalized into a second format.
- Determinism by construction: repo-relative paths (they end up in the logs), per-run retry markers under the cleaned scratch directory, and a failing flow that drains every task before it raises — no timing-dependent cancellations reach the record.

## Alternatives Considered

- Sanitized snapshot refs (strip nondeterministic fields into a normalized file): rejected — a second format to maintain, and the raw log stops being the reference.
- Full-record equality including timing: rejected — completion order and wall clock are not execution facts (`DR-012`).
- An artifact-hash manifest instead of real files: rejected — less inspectable than the artifacts themselves.

## Consequences

- Positive: version bumps and behavior changes surface as precise, reviewable diffs in CI; the reference doubles as executable documentation of the record's shape.
- Negative: intended changes require a reference-regeneration ritual (`UPDATE_REF=1`) plus a changelog note; new record fields fail the gate until regenerated — which is the point.
- The failing flow's shape (drain, then raise) is a constraint on the reference, not a general requirement of flows.

## Verification

- `e2e/test_flows.py`: update run, then ten consecutive compare passes green; full suite 267 tests; ruff clean.

## Review Trigger

- A third flow shape worth pinning (process-pool campaign, concurrent flows), or reference churn that grows noisier than the signal it protects.
