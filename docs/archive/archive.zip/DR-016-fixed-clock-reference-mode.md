---
id: DR-016
title: fixed_clock reference mode — byte-identical run logs for reference storage
summary: fixed_clock opts a run into reference mode — pinned run id, pinned timing, constant worker, canonical record order at close — so an identical run produces a byte-identical log file
date: 2026-10-19
status: accepted
layers: [product, architecture, implementation, verification]
state: docs/breakdown/01-product/uc-29-keep-a-run-log-byte-stable-for-reference-storage.md
artifacts:
  - src/sequence_extensions/flow/runlog.py
  - src/sequence_extensions/flow/flow.py
  - src/sequence_extensions/config.py
  - tests/flow/test_runlog.py
  - tests/flow/test_config.py
  - tests/e2e/test_flows.py
  - docs/API.md
  - README.md
  - CHANGELOG.md
supersedes: []
superseded_by: []
related: [DR-012, DR-015]
---

# DR-016: fixed_clock reference mode

## Context

- Identical runs churn run logs in four places: wall-clock timestamps,
  measured `duration_ms`, the `worker` thread that picked up each
  node, and record order (completion order under concurrency).
- `RunLog.diff` already excludes all four (`DIFF_EXCLUDE`, `DR-012`) —
  comparison is sound; committed logs as reference storage (golden
  files in git, the e2e `out/` tree) still dirty on every run.
- The e2e harness pinned the run id only, by monkeypatching the
  private id builder.

## Decision

- Added `fixed_clock` reference mode on three surfaces: `@flow(fixed_clock=True)`, `[flow] fixed_clock`, `RunLog(..., fixed_clock=True)`; default off, DR-015 precedence.
- Model: a frozen clock — run id pins to `<flow>-fixed` (the file overwrites itself), timing to the epoch, `duration_ms` to `0`, `worker` to a constant.
- Records flush at close in canonical order (`run_start`, tasks by task / attempt / inputs, `run_end`) with `seq` assigned in that order — on a frozen clock, completion order carries no information.
- One choke point: `RunLog.write` sees every record (worker attempts, timeout threads, process replay, settle skips), so `task.py` and `process_pool.py` are untouched and thread and process mode behave alike.
- Execution facts stay real; the e2e harness now uses the option instead of the monkeypatch.

## Rationale

- Evidence first: two consecutive e2e runs differed in timestamps,
  `duration_ms`, `worker`, and record order — pinning timestamps
  alone would have left the churn.
- The frozen-clock model covers all four with one honest concept and
  one option, instead of four flags nobody composes correctly.
- `RunLog.write` as the single choke point keeps `task.py` and the
  process path untouched — the mode cannot drift between execution
  paths.

## Alternatives Considered

- Pin timestamps only: rejected — record order and worker still churn
  (measured).
- Normalize after the run (rewrite the file in a post-processing
  step): rejected — product-less scripting, and the raw file still
  lands on disk first.
- Compare-time canonicalization only (`RunLog.diff`): rejected — sound
  comparison already exists; the need is stable bytes.
- A CLI flag or environment variable: rejected — the config surface
  (DR-015) already reaches every run uniformly.

## Consequences

- Positive: reference-file storage works — identical runs, identical
  bytes, no git churn; the e2e scratch tree stays clean; golden-file
  CI is one config key.
- Negative: a reference-mode log is not tail-able while the run is
  live (content lands at close); pinned timing is not performance
  evidence; records with fully identical identity keep arrival order,
  so a pathological duplicate submission could still churn.
- `run_start.version` still changes with the package version — a
  meaningful difference, excluded from the e2e comparison.

## Verification

- `tests/flow/test_runlog.py`: buffering until close, canonical
  ordering, seq renumbering, pinned fields, execution facts untouched.
- `tests/flow/test_config.py`: default off, config resolution, keyword
  beats config, byte-identical logs across identical concurrent runs;
  pinned replay from process mode.
- `tests/e2e/test_flows.py`: consecutive runs produce byte-identical
  `out/logs/*.jsonl` (checksums compared during development).

## Review Trigger

- A need for live tailing of reference-mode logs, or for user-chosen
  pinned instants instead of the epoch.
- A third record kind appears that carries engine-written timing the
  canonical pin misses.
